from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .api_client import ApiClientError, GSCertApiClient, ProjectMetadata
from .local_runner import ERROR, FAIL, PASS, UNSUPPORTED, LocalRunSummary, run_cached_rules
from .project import infer_project_number
from .rule_cache import RuleCacheSummary, load_rule_bundle, load_rule_cache, save_rule_cache
from .scanner import FolderScan, scan_folder


DEFAULT_SERVER_URL = "http://127.0.0.1:8000"

# ── Design tokens (ecm_download_review.css 기준) ─────────────────────────────
C_BG           = "#f4f6f8"
C_SURFACE      = "#ffffff"
C_SOFT         = "#f8fafc"
C_LINE         = "#d7dde5"
C_LINE_STRONG  = "#aeb8c5"
C_TEXT         = "#1f2937"
C_MUTED        = "#667085"
C_PRIMARY      = "#2563eb"
C_PRIMARY_SOFT = "#e8f0ff"
C_SUCCESS      = "#067647"
C_SUCCESS_SOFT = "#e7f6ee"
C_WARNING      = "#b54708"
C_WARNING_SOFT = "#fff4e5"
C_DANGER       = "#b42318"
C_DANGER_SOFT  = "#fdecec"

STATUS_META = {
    PASS:        (C_SUCCESS, C_SUCCESS_SOFT, "적합"),
    FAIL:        (C_DANGER,  C_DANGER_SOFT,  "부적합"),
    UNSUPPORTED: (C_MUTED,   "#eef2f6",      "미지원"),
    ERROR:       (C_WARNING, C_WARNING_SOFT, "오류"),
}

REVIEW_COLOR = {
    "완료":     C_SUCCESS,
    "수정 필요": C_WARNING,
    "보류":     C_MUTED,
}

APP_QSS = f"""
/* ── Base ─────────────────────────────────── */
QMainWindow, QDialog {{
    background-color: {C_BG};
}}
QWidget {{
    font-family: "Malgun Gothic", "Segoe UI", Arial, sans-serif;
    font-size: 13px;
    color: {C_TEXT};
}}

/* ── Scrollbars ────────────────────────────── */
QScrollBar:vertical {{
    width: 7px;
    background: transparent;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {C_LINE_STRONG};
    border-radius: 3px;
    min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{
    height: 7px;
    background: transparent;
}}
QScrollBar::handle:horizontal {{
    background: {C_LINE_STRONG};
    border-radius: 3px;
    min-width: 20px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

/* ── Panel cards ───────────────────────────── */
QFrame#panel {{
    background-color: {C_SURFACE};
    border: 1px solid {C_LINE};
    border-radius: 8px;
}}

/* ── Inputs ────────────────────────────────── */
QLineEdit, QComboBox {{
    min-height: 34px;
    padding: 0 10px;
    border: 1px solid {C_LINE};
    border-radius: 6px;
    background-color: {C_SURFACE};
    color: {C_TEXT};
}}
QLineEdit:focus, QComboBox:focus {{
    border-color: {C_PRIMARY};
}}
QLineEdit:read-only {{
    background-color: {C_SOFT};
    color: {C_MUTED};
}}
QComboBox::drop-down {{
    border: none;
    width: 22px;
}}
QComboBox QAbstractItemView {{
    border: 1px solid {C_LINE};
    border-radius: 6px;
    background: {C_SURFACE};
    selection-background-color: {C_PRIMARY_SOFT};
    selection-color: {C_TEXT};
    outline: none;
}}

/* ── Buttons ───────────────────────────────── */
QPushButton {{
    min-height: 34px;
    padding: 0 14px;
    border: 1px solid {C_LINE};
    border-radius: 6px;
    background-color: {C_SURFACE};
    color: {C_TEXT};
    font-weight: 600;
}}
QPushButton:hover {{
    background-color: {C_SOFT};
    border-color: {C_LINE_STRONG};
}}
QPushButton:pressed {{
    background-color: #edf0f4;
}}
QPushButton:disabled {{
    color: #98a2b3;
    background-color: #eef2f6;
    border-color: {C_LINE_STRONG};
}}
QPushButton#primaryBtn {{
    background-color: {C_PRIMARY};
    color: #ffffff;
    border-color: {C_PRIMARY};
    font-weight: 700;
}}
QPushButton#primaryBtn:hover {{
    background-color: #1d4ed8;
    border-color: #1d4ed8;
}}
QPushButton#primaryBtn:pressed {{
    background-color: #1e40af;
}}

/* ── Tables ────────────────────────────────── */
QTableWidget {{
    background-color: {C_SURFACE};
    border: 1px solid {C_LINE};
    border-radius: 8px;
    gridline-color: #edf0f4;
    selection-background-color: {C_PRIMARY_SOFT};
    selection-color: {C_TEXT};
    outline: none;
}}
QTableWidget::item {{
    padding: 7px 10px;
    border-bottom: 1px solid #edf0f4;
}}
QTableWidget::item:selected {{
    background-color: {C_PRIMARY_SOFT};
    color: {C_TEXT};
}}
QTableWidget[alternatingRowColors="true"]::item:alternate {{
    background-color: {C_SOFT};
}}
QHeaderView::section {{
    background-color: {C_SOFT};
    color: #475467;
    font-weight: 700;
    font-size: 12px;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid {C_LINE};
    border-right: 1px solid {C_LINE};
}}
QHeaderView::section:last {{
    border-right: none;
}}

/* ── Splitter ──────────────────────────────── */
QSplitter::handle {{
    background-color: {C_LINE};
}}
QSplitter::handle:horizontal {{
    width: 1px;
    margin: 4px 0;
}}
QSplitter::handle:vertical {{
    height: 1px;
    margin: 0 4px;
}}
"""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _panel() -> QFrame:
    f = QFrame()
    f.setObjectName("panel")
    return f


def _section_title(text: str) -> QLabel:
    lbl = QLabel(text)
    font = lbl.font()
    font.setPointSize(11)
    font.setBold(True)
    lbl.setFont(font)
    lbl.setStyleSheet(f"color: {C_TEXT}; background: transparent; border: none;")
    return lbl


def _muted(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color: {C_MUTED}; font-size: 12px; background: transparent; border: none;")
    return lbl


def _hsep() -> QFrame:
    sep = QFrame()
    sep.setFrameShape(QFrame.Shape.HLine)
    sep.setStyleSheet(f"color: {C_LINE}; background-color: {C_LINE}; border: none; max-height: 1px;")
    return sep


def _vsep() -> QFrame:
    sep = QFrame()
    sep.setFrameShape(QFrame.Shape.VLine)
    sep.setStyleSheet(f"color: {C_LINE}; background-color: {C_LINE}; border: none; max-width: 1px;")
    return sep


def _stat_badge(text: str, fg: str, bg: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"""
        background-color: {bg};
        color: {fg};
        border-radius: 10px;
        padding: 2px 10px;
        font-size: 12px;
        font-weight: 700;
        border: none;
    """)
    return lbl


# ── Main window ───────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GSCert Local Review")
        self.resize(1300, 840)
        self.selected_folder: Path | None = None
        self.scan: FolderScan | None = None
        self.rule_cache = load_rule_cache()

        root = QWidget()
        root.setStyleSheet(f"background-color: {C_BG};")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(10)

        outer.addWidget(self._build_header())
        outer.addWidget(self._build_controls())
        outer.addWidget(self._build_body(), stretch=1)

        self.setCentralWidget(root)

    # ── Header ────────────────────────────────────────────────────────────────

    def _build_header(self) -> QFrame:
        frame = _panel()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(18, 13, 18, 13)
        layout.setSpacing(0)

        # Left: title
        left = QVBoxLayout()
        left.setSpacing(2)
        eyebrow = QLabel("GSCert · ECM 제출물 점검 도구")
        eyebrow.setStyleSheet(
            f"color: {C_MUTED}; font-size: 11px; font-weight: 700;"
            " background: transparent; border: none;"
        )
        title = QLabel("GSCert Local Review")
        title.setStyleSheet(
            f"color: {C_TEXT}; font-size: 20px; font-weight: 800;"
            " background: transparent; border: none;"
        )
        left.addWidget(eyebrow)
        left.addWidget(title)

        # Right: server connection
        right = QHBoxLayout()
        right.setSpacing(8)

        url_col = QVBoxLayout()
        url_col.setSpacing(3)
        url_col.addWidget(_muted("서버 URL"))
        self.server_url = QLineEdit(DEFAULT_SERVER_URL)
        self.server_url.setMinimumWidth(220)
        url_col.addWidget(self.server_url)

        center_col = QVBoxLayout()
        center_col.setSpacing(3)
        center_col.addWidget(_muted("센터"))
        self.center = QComboBox()
        self.center.addItem("상암", "sangam")
        self.center.addItem("영남", "yeongnam")
        self.center.setFixedWidth(86)
        center_col.addWidget(self.center)

        btn_col = QVBoxLayout()
        btn_col.setSpacing(3)
        btn_col.addWidget(QLabel(" "))  # spacer to align with labels above
        health_btn = QPushButton("연결 확인")
        health_btn.setFixedWidth(90)
        health_btn.clicked.connect(self.check_health)
        btn_col.addWidget(health_btn)

        right.addLayout(url_col)
        right.addLayout(center_col)
        right.addLayout(btn_col)

        layout.addLayout(left)
        layout.addStretch()
        layout.addLayout(right)
        return frame

    # ── Controls bar ─────────────────────────────────────────────────────────

    def _build_controls(self) -> QFrame:
        frame = _panel()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(18, 12, 18, 12)
        layout.setSpacing(0)

        layout.addLayout(self._build_rulebase_section())
        layout.addWidget(_vsep())
        layout.addSpacing(16)
        layout.addLayout(self._build_folder_section(), stretch=1)
        return frame

    def _build_rulebase_section(self) -> QVBoxLayout:
        vbox = QVBoxLayout()
        vbox.setSpacing(6)

        cap = QLabel("RULEBASE")
        cap.setStyleSheet(
            f"color: {C_MUTED}; font-size: 11px; font-weight: 700;"
            " background: transparent; border: none;"
        )

        row = QHBoxLayout()
        row.setSpacing(6)
        self.rulebase_status = QLabel(self._rule_cache_text(self.rule_cache))
        self.rulebase_status.setMinimumWidth(180)
        self.rulebase_status.setStyleSheet(
            f"color: {C_TEXT}; font-size: 12px; background: transparent; border: none;"
        )
        manifest_btn = QPushButton("버전 확인")
        manifest_btn.setFixedWidth(80)
        manifest_btn.clicked.connect(self.check_rule_manifest)
        update_btn = QPushButton("규칙 업데이트")
        update_btn.setFixedWidth(100)
        update_btn.clicked.connect(self.update_rules)

        row.addWidget(self.rulebase_status)
        row.addWidget(manifest_btn)
        row.addWidget(update_btn)

        vbox.addWidget(cap)
        vbox.addLayout(row)
        return vbox

    def _build_folder_section(self) -> QVBoxLayout:
        vbox = QVBoxLayout()
        vbox.setSpacing(6)
        vbox.setContentsMargins(16, 0, 0, 0)

        cap = QLabel("점검 폴더")
        cap.setStyleSheet(
            f"color: {C_MUTED}; font-size: 11px; font-weight: 700;"
            " background: transparent; border: none;"
        )

        row1 = QHBoxLayout()
        row1.setSpacing(6)
        self.folder_path = QLineEdit()
        self.folder_path.setReadOnly(True)
        self.folder_path.setPlaceholderText("점검 대상 폴더를 선택하세요")
        browse_btn = QPushButton("폴더 선택")
        browse_btn.setFixedWidth(88)
        browse_btn.clicked.connect(self.choose_folder)
        row1.addWidget(self.folder_path, stretch=1)
        row1.addWidget(browse_btn)

        row2 = QHBoxLayout()
        row2.setSpacing(6)
        pn_label = _muted("프로젝트 번호")
        self.project_number = QLineEdit()
        self.project_number.setPlaceholderText("TTA-26-00000")
        self.project_number.setFixedWidth(140)
        metadata_btn = QPushButton("기준정보 조회")
        metadata_btn.setFixedWidth(100)
        metadata_btn.clicked.connect(self.fetch_metadata)
        scan_btn = QPushButton("파일 스캔")
        scan_btn.setFixedWidth(80)
        scan_btn.clicked.connect(self.scan_files)
        run_btn = QPushButton("점검 실행")
        run_btn.setObjectName("primaryBtn")
        run_btn.setFixedWidth(90)
        run_btn.clicked.connect(self.run_local_review)
        row2.addWidget(pn_label)
        row2.addWidget(self.project_number)
        row2.addWidget(metadata_btn)
        row2.addWidget(scan_btn)
        row2.addStretch()
        row2.addWidget(run_btn)

        vbox.addWidget(cap)
        vbox.addLayout(row1)
        vbox.addLayout(row2)
        return vbox

    # ── Body: left sidebar + result panel ────────────────────────────────────

    def _build_body(self) -> QSplitter:
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(10)
        splitter.setChildrenCollapsible(False)

        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_result_panel())
        splitter.setSizes([320, 940])
        return splitter

    # ── Left panel: metadata + file list ─────────────────────────────────────

    def _build_left_panel(self) -> QWidget:
        w = QWidget()
        w.setStyleSheet(f"background-color: {C_BG};")
        layout = QVBoxLayout(w)
        layout.setContentsMargins(0, 0, 6, 0)
        layout.setSpacing(10)
        layout.addWidget(self._build_metadata_card())
        layout.addWidget(self._build_file_card(), stretch=1)
        return w

    def _build_metadata_card(self) -> QFrame:
        frame = _panel()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(16, 13, 16, 13)
        layout.setSpacing(10)

        layout.addWidget(_section_title("프로젝트 정보"))
        layout.addWidget(_hsep())

        grid = QGridLayout()
        grid.setSpacing(7)
        grid.setColumnMinimumWidth(0, 72)
        grid.setColumnStretch(1, 1)

        fields = [
            ("회사명", "company"),
            ("제품명", "product"),
            ("PL",    "pl"),
            ("WD",    "wd"),
            ("인증일", "cert_date"),
            ("점검결과", "review"),
        ]
        for i, (label_text, attr_name) in enumerate(fields):
            key_lbl = QLabel(label_text)
            key_lbl.setStyleSheet(
                f"color: {C_MUTED}; font-size: 12px; font-weight: 600;"
                " background: transparent; border: none;"
            )
            val_lbl = QLabel("—")
            val_lbl.setWordWrap(True)
            val_lbl.setStyleSheet(
                f"color: {C_TEXT}; font-size: 12px;"
                " background: transparent; border: none;"
            )
            setattr(self, attr_name, val_lbl)
            grid.addWidget(key_lbl, i, 0, Qt.AlignTop)
            grid.addWidget(val_lbl, i, 1, Qt.AlignTop)

        layout.addLayout(grid)
        return frame

    def _build_file_card(self) -> QFrame:
        frame = _panel()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(16, 13, 16, 13)
        layout.setSpacing(8)

        header = QHBoxLayout()
        header.addWidget(_section_title("파일 목록"))
        header.addStretch()
        self.file_count_label = _muted("0개")
        header.addWidget(self.file_count_label)
        layout.addLayout(header)
        layout.addWidget(_hsep())

        self.file_table = QTableWidget(0, 3)
        self.file_table.setHorizontalHeaderLabels(["파일명", "확장자", "크기(B)"])
        hdr = self.file_table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.file_table.verticalHeader().setVisible(False)
        self.file_table.setSortingEnabled(True)
        self.file_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.file_table.setAlternatingRowColors(True)
        layout.addWidget(self.file_table, stretch=1)
        return frame

    # ── Result panel ──────────────────────────────────────────────────────────

    def _build_result_panel(self) -> QFrame:
        frame = _panel()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(10)

        # Header row: title + stat badges
        header = QHBoxLayout()
        title = _section_title("점검 결과")
        title_font = title.font()
        title_font.setPointSize(13)
        title.setFont(title_font)
        header.addWidget(title)
        header.addStretch()

        self._stat_labels: dict[str, QLabel] = {}
        for key, fg, bg, text in [
            ("total",       C_TEXT,    "#eef2f6",      "전체 0"),
            ("pass",        C_SUCCESS, C_SUCCESS_SOFT, "적합 0"),
            ("fail",        C_DANGER,  C_DANGER_SOFT,  "부적합 0"),
            ("unsupported", C_MUTED,   "#eef2f6",      "미지원 0"),
            ("error",       C_WARNING, C_WARNING_SOFT, "오류 0"),
        ]:
            badge = _stat_badge(text, fg, bg)
            self._stat_labels[key] = badge
            header.addWidget(badge)

        layout.addLayout(header)
        layout.addWidget(_hsep())

        # Result table
        self.result_table = QTableWidget(0, 5)
        self.result_table.setHorizontalHeaderLabels(["결과", "점검항목", "기대값", "실제값", "메시지"])
        hdr = self.result_table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.result_table.setColumnWidth(0, 70)
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        hdr.setStretchLastSection(False)
        self.result_table.verticalHeader().setVisible(False)
        self.result_table.setSortingEnabled(True)
        self.result_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.result_table.setWordWrap(True)
        self.result_table.setAlternatingRowColors(True)
        layout.addWidget(self.result_table, stretch=1)
        return frame

    # ── Business logic ────────────────────────────────────────────────────────

    def check_health(self):
        try:
            payload = self._client().health()
        except ApiClientError as exc:
            self._show_error(str(exc))
            return
        QMessageBox.information(self, "연결 확인", f"서버 연결 정상\n{payload.get('server_time', '')}")

    def check_rule_manifest(self):
        try:
            manifest = self._client().rule_manifest()
        except ApiClientError as exc:
            self._show_error(str(exc))
            return
        cached = self.rule_cache.rulebase_version or "(없음)"
        server = manifest.get("rulebase_version") or "(없음)"
        QMessageBox.information(
            self,
            "규칙 버전 확인",
            "\n".join([
                f"서버 규칙 버전: {server}",
                f"로컬 규칙 버전: {cached}",
                f"규칙 개수: {manifest.get('rule_count', 0)}",
                f"필요 엔진 버전: {manifest.get('engine_min_version', '')}",
            ]),
        )

    def update_rules(self):
        try:
            bundle = self._client().rule_bundle()
            self.rule_cache = save_rule_cache(bundle)
        except ApiClientError as exc:
            self._show_error(str(exc))
            return
        except OSError as exc:
            self._show_error(f"규칙 캐시 저장에 실패했습니다: {exc}")
            return
        self.rulebase_status.setText(self._rule_cache_text(self.rule_cache))
        QMessageBox.information(
            self,
            "규칙 업데이트",
            f"규칙을 업데이트했습니다.\n버전: {self.rule_cache.rulebase_version}\n규칙 수: {self.rule_cache.rule_count}",
        )

    def choose_folder(self):
        folder_name = QFileDialog.getExistingDirectory(self, "점검 대상 폴더 선택")
        if not folder_name:
            return
        folder = Path(folder_name)
        self.selected_folder = folder
        self.folder_path.setText(str(folder))
        inferred = infer_project_number(folder)
        if inferred and not self.project_number.text().strip():
            self.project_number.setText(inferred)
        self.scan_files()

    def fetch_metadata(self):
        project_number = self.project_number.text().strip()
        if not project_number:
            self._show_error("프로젝트 번호를 입력하거나 프로젝트 번호가 포함된 폴더를 선택하세요.")
            return
        try:
            metadata = self._client().project_metadata(project_number, self.center.currentData())
        except ApiClientError as exc:
            self._show_error(str(exc))
            return
        self._set_metadata(metadata)

    def scan_files(self):
        folder_text = self.folder_path.text().strip()
        if not folder_text:
            self._show_error("먼저 점검 대상 폴더를 선택하세요.")
            return
        folder = Path(folder_text)
        if not folder.is_dir():
            self._show_error("선택한 폴더가 존재하지 않습니다.")
            return
        self.scan = scan_folder(folder)
        self._set_file_rows(self.scan)

    def run_local_review(self):
        if self.scan is None:
            self.scan_files()
        if self.scan is None:
            return
        rule_bundle = load_rule_bundle()
        if not rule_bundle:
            self._show_error("먼저 Rulebase에서 규칙 업데이트를 실행하세요.")
            return
        summary = run_cached_rules(
            self.scan,
            rule_bundle,
            self.project_number.text().strip(),
        )
        self._set_result_rows(summary)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _client(self) -> GSCertApiClient:
        return GSCertApiClient(self.server_url.text().strip() or DEFAULT_SERVER_URL)

    def _rule_cache_text(self, summary: RuleCacheSummary) -> str:
        if not summary.exists:
            return "로컬 규칙 없음"
        return f"v{summary.rulebase_version} · {summary.rule_count}개 규칙"

    def _set_metadata(self, metadata: ProjectMetadata):
        self.company.setText(metadata.company_name or "—")
        self.product.setText(metadata.product_name or "—")
        self.pl.setText(metadata.pl_name or "—")
        self.wd.setText(metadata.wd_name or "—")
        self.cert_date.setText(metadata.cert_date or "—")
        review_text = metadata.review or "—"
        color = REVIEW_COLOR.get(review_text, C_TEXT)
        self.review.setText(review_text)
        self.review.setStyleSheet(
            f"color: {color}; font-size: 12px; font-weight: 700;"
            " background: transparent; border: none;"
        )

    def _set_file_rows(self, scan: FolderScan):
        self.file_table.setSortingEnabled(False)
        self.file_table.setRowCount(len(scan.files))
        self.file_count_label.setText(f"{scan.file_count}개 · {scan.total_size_mb} MB")
        for row, file in enumerate(scan.files):
            for col, value in enumerate([file.name, file.extension, str(file.size_bytes)]):
                item = QTableWidgetItem(value)
                if col == 2:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.file_table.setItem(row, col, item)
        self.file_table.setSortingEnabled(True)

    def _set_result_rows(self, summary: LocalRunSummary):
        self.result_table.setSortingEnabled(False)
        self.result_table.setRowCount(len(summary.results))

        counts = {PASS: 0, FAIL: 0, UNSUPPORTED: 0, ERROR: 0}
        for row, result in enumerate(summary.results):
            counts[result.status] = counts.get(result.status, 0) + 1
            fg, bg, label = STATUS_META.get(result.status, (C_TEXT, C_SOFT, result.status))

            status_item = QTableWidgetItem(label)
            status_item.setTextAlignment(Qt.AlignCenter)
            status_item.setForeground(QColor(fg))
            status_item.setBackground(QColor(bg))
            self.result_table.setItem(row, 0, status_item)

            for col, value in enumerate(
                [result.rule_name, result.expected, result.actual, result.message],
                start=1,
            ):
                self.result_table.setItem(row, col, QTableWidgetItem(value))

        self._stat_labels["total"].setText(f"전체 {len(summary.results)}")
        self._stat_labels["pass"].setText(f"적합 {counts.get(PASS, 0)}")
        self._stat_labels["fail"].setText(f"부적합 {counts.get(FAIL, 0)}")
        self._stat_labels["unsupported"].setText(f"미지원 {counts.get(UNSUPPORTED, 0)}")
        self._stat_labels["error"].setText(f"오류 {counts.get(ERROR, 0)}")

        self.result_table.resizeRowsToContents()
        self.result_table.setSortingEnabled(True)

    def _show_error(self, message: str):
        QMessageBox.warning(self, "GSCert Local Review", message)


def main() -> int:
    app = QApplication([])
    app.setStyleSheet(APP_QSS)
    window = MainWindow()
    window.show()
    return app.exec()
